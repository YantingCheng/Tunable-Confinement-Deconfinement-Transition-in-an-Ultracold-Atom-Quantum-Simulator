N=20;%site number
t=1;
m=1;%mass of a matter field particle
b=0;%tune the topological angle

insertion_site=10;

H0=t/2*SpinChainH('Y',N,'pbc')-m*SpinChainH('Z',N,'pbc');
for j=1:N
    H0=H0+b*(-1).^j*OnsitePauliMString('Z',j,N);
end


if m>0

    L0=true(2^N,1);
    for i=1:N
        if i==insertion_site
            F=diag(OnsitePauliMString('Z',i,N)+OnsitePauliMString('Z',mod(i,N)+1,N));
        else
            F=1/2+diag(1/2*OnsitePauliMString('ZZ',i,N)+1/2*OnsitePauliMString('Z',i,N)+1/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        end
        L0=L0&(F==0);
    end

    H_eff=H0(L0,L0);
    [gv, genergy] = eigs(H_eff,1,'smallestreal');
    v0=zeros(2^N,1);
    v0(L0)=gv;

    L1=true(2^N,1);
    for i=1:N
        if i==insertion_site
            F=1/2+diag(1/2*OnsitePauliMString('ZZ',i,N)-1/2*OnsitePauliMString('Z',i,N)-1/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        else
            F=1/2+diag(1/2*OnsitePauliMString('ZZ',i,N)+1/2*OnsitePauliMString('Z',i,N)+1/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        end
        L1=L1&(F==0);
    end

    H1=H0(L1,L1);
    N_eigenval=100;
    [ev, eigenenergy] = eigs(H1,N_eigenval,'smallestreal');
    v1=zeros(2^N,N_eigenval);
    v1(L1,:)=ev;

    t_start = 0;
    t_end = 50;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ;
    step = .1;
    y = t_start:step:(t_end-t_start-step);

    psi=v1*(exp(-1i*diag(eigenenergy)*y).*(v1'*v0));

    charge=zeros(N,length(y));

    for j=1:N

        charge(j,:)=1/2*sum(conj(psi).*((-OnsitePauliMString(3,mod(j,N)+1,N)-OnsitePauliMString(3,j,N))*psi),1);

    end

    test_charge=zeros(N,1);
    test_charge(insertion_site)=1;

    phys_charge=charge+test_charge;
    h=surf(1:N,y,phys_charge.');
    set(h,'edgecolor','none');
    view([0,0,1]);
    set(gcf,'Renderer','Painters');
    xlabel('$n$','fontsize',14,'Interpreter','latex');
    ylabel('$t$','fontsize',14,'Interpreter','latex');
    set(gca,'TickLabelInterpreter', 'latex');
    set(gca,'fontsize',14);
    colorbar;
    caxis([0,1]);
    TheColorBar=colorbar;
    TheColorBar.Label.String='charge';
    TheColorBar.Label.Interpreter='latex'; 
    TheColorBar.TickLabelInterpreter='latex';
    xlim([1,N]);
else
    L0=true(2^N,1);
    for i=1:N
        if i==insertion_site
            F=1+1/2*diag(OnsitePauliMString('Z',i,N)+OnsitePauliMString('Z',mod(i,N)+1,N));
        else
            F=1/2+diag(1/2*OnsitePauliMString('ZZ',i,N)+1/2*OnsitePauliMString('Z',i,N)+1/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        end
        L0=L0&(F==0);
    end

    H_eff=H0(L0,L0);
    [gv, genergy] = eigs(H_eff,1,'smallestreal');
    v0=zeros(2^N,1);
    v0(L0)=gv;

    L1=true(2^N,1);
    for i=1:N
        if i==insertion_site
            F=5/2+diag(1/2*OnsitePauliMString('ZZ',i,N)+3/2*OnsitePauliMString('Z',i,N)+3/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        else
            F=1/2+diag(1/2*OnsitePauliMString('ZZ',i,N)+1/2*OnsitePauliMString('Z',i,N)+1/2*OnsitePauliMString('Z',mod(i,N)+1,N));
        end
        L1=L1&(F==0);
    end

    H1=H0(L1,L1);
    N_eigenval=100;
    [ev, eigenenergy] = eigs(H1,N_eigenval,'smallestreal');
    v1=zeros(2^N,N_eigenval);
    v1(L1,:)=ev;

    t_start = 0;
    t_end = 50;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ;
    step = .1;
    y = t_start:step:(t_end-t_start-step);

    psi=v1*(exp(-1i*diag(eigenenergy)*y).*(v1'*v0));

    charge=zeros(N,length(y));

    for j=1:N

        charge(j,:)=1/2*sum(conj(psi).*((-OnsitePauliMString(3,mod(j,N)+1,N)-OnsitePauliMString(3,j,N))*psi),1);

    end

    test_charge=zeros(N,1);
    test_charge(insertion_site)=-1;

    phys_charge=charge+test_charge;
    h=surf(1:N,y,phys_charge.');
    set(h,'edgecolor','none');
    view([0,0,1]);
    set(gcf,'Renderer','Painters');
    xlabel('$n$','fontsize',14,'Interpreter','latex');
    ylabel('$t$','fontsize',14,'Interpreter','latex');
    set(gca,'TickLabelInterpreter', 'latex');
    set(gca,'fontsize',14);
    colorbar;
    caxis([0,1]);
    TheColorBar=colorbar;
    TheColorBar.Label.String='charge';
    TheColorBar.Label.Interpreter='latex'; 
    TheColorBar.TickLabelInterpreter='latex';
    xlim([1,N]);
    
end

